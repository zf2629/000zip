# coding=utf-8
"""
目标站: 追剧吧 (https://www.zjuba3.com)
模板: MacCMS V10
功能: 首页推荐 / 二级分类筛选 / 详情多线路 / 搜索 / 播放解析
优化: 正则预编译、单次请求、惰性解析、域名缓存、m3u8可达性检测

修复 (v2):
  [关键] 图片防盗链 —— 图床 pic1.imgdb.cn 禁止带 Referer 访问，
         一旦带 Referer 返回 403 (连占位图都会破图/空白)。
         解法: 将图片 URL 统一经 images.weserv.nl 代理转发，
         代理请求时不带 Referer, 即可稳定返回 HTTP 200 真图。
  [加固] 新增 _proxy_pic() 统一出口, 首页列表 + 详情封面全部过代理。
"""
import re
import sys
import json
import urllib.parse

sys.path.append('..')
from base.spider import Spider


class Spider(Spider):

    # ===================== 初始化 =====================
    def init(self, extend=""):
        self.site_url = "https://www.zjuba3.com"

        # 图片防盗链代理: 图床禁止带Referer, 用weserv转发(不带Referer)绕过
        self.img_proxy = "https://images.weserv.nl/?url="

        # 站点请求头
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                          'AppleWebKit/537.36 (KHTML, like Gecko) '
                          'Chrome/120.0.0.0 Safari/537.36',
            'Referer': self.site_url + '/',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.9',
            'Connection': 'keep-alive',
        }

        # 播放专用头 (精简)
        self.play_headers = {
            'User-Agent': self.headers['User-Agent'],
            'Referer': self.site_url + '/',
        }

        # 一级分类
        self.categories = [
            {"type_id": "1",  "type_name": "电影"},
            {"type_id": "2",  "type_name": "连续剧"},
            {"type_id": "3",  "type_name": "综艺"},
            {"type_id": "4",  "type_name": "动漫"},
            {"type_id": "6",  "type_name": "动作片"},
            {"type_id": "7",  "type_name": "喜剧片"},
            {"type_id": "8",  "type_name": "爱情片"},
            {"type_id": "9",  "type_name": "科幻片"},
            {"type_id": "10", "type_name": "恐怖片"},
            {"type_id": "11", "type_name": "剧情片"},
            {"type_id": "12", "type_name": "战争片"},
            {"type_id": "13", "type_name": "国产剧"},
            {"type_id": "14", "type_name": "港台剧"},
            {"type_id": "15", "type_name": "日韩剧"},
            {"type_id": "16", "type_name": "欧美剧"},
        ]

        # 二级分类筛选器
        _class_opts = self._build_opts([
            "动作", "喜剧", "爱情", "科幻", "恐怖", "剧情", "战争", "犯罪",
            "武侠", "历史", "冒险", "经典", "儿童", "古装", "农村", "警匪",
            "奇幻", "悬疑", "微电影", "惊悚", "枪战", "动画", "家庭", "传记",
            "歌舞", "音乐", "运动", "灾难", "西部", "短片", "纪录片", "伦理",
            "青春", "励志", "商战", "谍战", "革命", "年代", "都市", "言情",
            "偶像", "军旅", "情景", "神话", "穿越", "宫廷", "罪案", "刑侦",
            "反腐", "抗战", "传奇", "生活", "乡土", "红色",
        ])
        _area_opts = self._build_opts([
            "大陆", "香港", "台湾", "美国", "法国", "英国", "日本", "韩国",
            "德国", "泰国", "印度", "意大利", "西班牙", "加拿大", "其他",
        ])
        _by_opts = [
            {"n": "时间", "v": "time"},
            {"n": "人气", "v": "hits"},
            {"n": "评分", "v": "score"},
        ]

        filter_tpl = [
            {"key": "class", "name": "剧情", "value": _class_opts},
            {"key": "area",  "name": "地区", "value": _area_opts},
            {"key": "by",    "name": "排序", "value": _by_opts},
        ]
        self.filters = {c["type_id"]: filter_tpl for c in self.categories}

        # ---- 预编译正则 ----
        self._re_detail_anchor = re.compile(
            r'<a[ \t][^>]*href="(/index\.php/vod/detail/id/(\d+)\.html)"[^>]*title="([^"]*)"[^>]*>',
            re.DOTALL
        )
        self._re_detail_anchor_no_title = re.compile(
            r'<a[ \t][^>]*href="(/index\.php/vod/detail/id/(\d+)\.html)"[^>]*>',
            re.DOTALL
        )
        self._re_data_original = re.compile(r'data-original="([^"]+)"')
        self._re_img_src = re.compile(r'<img[^>]*\bsrc="([^"]+\.(?:jpg|jpeg|png|webp))"[^>]*>', re.IGNORECASE)
        self._re_img_alt = re.compile(r'<img[^>]*\balt="([^"]+)"[^>]*>')
        self._re_item_text = re.compile(r'module-item-text[^>]*>([^<]+)<')
        self._re_poster_title = re.compile(r'module-poster-item-title[^>]*>([^<]+)<')
        self._re_card_title = re.compile(r'module-card-item-title[^>]*>.*?>([^<]+)<', re.DOTALL)
        self._re_card_poster = re.compile(
            r'<a[ \t][^>]*href="(/index\.php/vod/detail/id/(\d+)\.html)"[^>]*class="[^"]*module-card-item-poster[^"]*"[^>]*>',
            re.DOTALL
        )
        self._re_item_note = re.compile(r'module-item-note[^>]*>([^<]+)<')
        self._re_play_link = re.compile(
            r'href="(/index\.php/vod/play/id/\d+/sid/(\d+)/nid/(\d+)\.html)"'
        )
        self._re_play_url_parts = re.compile(
            r'/vod/play/id/(\d+)/sid/(\d+)/nid/(\d+)'
        )
        self._re_player_var = re.compile(
            r'var player_[^{]*=\s*(\{.*?\});',
            re.DOTALL
        )
        self._re_m3u8_in_json = re.compile(r'"url"[ \t]*:[ \t]*"([^"]+\.m3u8[^"]*)"')
        self._re_m3u8_direct = re.compile(r'https?://[^\s"\'<>]+\.m3u8[^\s"\'<>]*')
        self._re_pagination = re.compile(r'/vod/show/id/\d+/page/(\d+)\.html')
        self._re_search_pg = re.compile(r'/vod/search/page/(\d+)/wd/')
        self._re_total = re.compile(r'共[ \t]*(\d+)[ \t]*(条|部|个|页|影片)?')
        self._re_all_sids = re.compile(r'sid/(\d+)/nid/')
        self._re_line_name = re.compile(
            r'module-tab-item[^>]*data-dropdown-value="([^"]*)"'
        )
        self._re_title_h1 = re.compile(
            r'<h1[^>]*>([^<]{1,80})</h1>'
        )
        self._re_title_tag = re.compile(r'<title>([^<]+)</title>')
        self._re_content = re.compile(
            r'class="[^"]*content[^"]*"[^>]*>(.*?)</div>',
            re.DOTALL
        )
        self._re_director = re.compile(
            r'导演[\s:：]*</span>[ \t]*<div[^>]*>(.*?)</div>',
            re.DOTALL
        )
        self._re_actor = re.compile(
            r'主演[\s:：]*</span>[ \t]*<div[^>]*>(.*?)</div>',
            re.DOTALL
        )
        self._re_year_area = re.compile(
            r'href="/index\.php/vod/search/(year|area)/([^"]+)\.html"[^>]*>([^<]+)<'
        )

        # 域名缓存
        self._alive_domains = set()
        self._dead_domains = set()

    @staticmethod
    def _build_opts(names):
        seen = set()
        opts = [{"n": "全部", "v": ""}]
        for n in names:
            if n and n not in seen:
                seen.add(n)
                opts.append({"n": n, "v": n})
        return opts

    # ===================== 工具方法 =====================
    def _fix_url(self, url):
        if not url:
            return ''
        if url.startswith('http'):
            return url
        if url.startswith('//'):
            return 'https:' + url
        if url.startswith('/'):
            return self.site_url + url
        return self.site_url + '/' + url

    def _proxy_pic(self, url):
        """
        图片防盗链代理:
        图床 pic1.imgdb.cn 对带 Referer 的请求返回 403, 导致 App 里破图。
        经 images.weserv.nl 转发时该代理不带 Referer, 可稳定取到真图。
        已是代理链接则原样返回。
        """
        if not url:
            return ''
        if url.startswith(self.img_proxy):
            return url
        # 只代理图片图床域名, 其它地址(如自建CDN)保留原样
        if 'imgdb.cn' in url:
            host = url.split('://', 1)[-1]
            return self.img_proxy + host
        return url

    def _fetch(self, url, max_retry=1):
        """单次请求，默认仅1次重试"""
        for _ in range(max_retry + 1):
            try:
                resp = self.fetch(url, headers=self.headers)
                if resp and resp.text:
                    return resp
            except Exception:
                pass
        return None

    def _check_m3u8_alive(self, m3u8_url):
        """快速检测 m3u8 是否可达"""
        dm_m = re.match(r'https?://([^/]+)', m3u8_url)
        if not dm_m:
            return False
        domain = dm_m.group(1)

        if domain in self._alive_domains:
            return True
        if domain in self._dead_domains:
            return False

        try:
            resp = self.fetch(m3u8_url, headers=self.play_headers)
            if resp and resp.text and '#EXTM3U' in resp.text[:100]:
                self._alive_domains.add(domain)
                return True
        except Exception:
            pass
        self._dead_domains.add(domain)
        return False

    def _parse_list_regex(self, html):
        """
        正则解析视频列表, 同时兼容:
          - module-poster-item: 首页 / 分类页
          - module-card-item : 搜索页 (无 title 属性)
        图片统一走防盗链代理。
        根据页面特征二选一, 避免搜索页中 title-less 链接污染 seen。
        """
        results = []
        seen = set()

        # 判断当前页面是否为搜索页 (module-card-item 卡片)
        is_card_page = 'module-card-item' in html

        if is_card_page:
            # ---------------- 模式B: module-card-item (搜索页) ----------------
            for m in self._re_card_poster.finditer(html):
                vod_id = m.group(2)
                if vod_id in seen:
                    continue
                seen.add(vod_id)

                ctx_start = max(0, m.start() - 50)
                ctx_end = min(len(html), m.end() + 800)
                chunk = html[ctx_start:ctx_end]

                # 标题: 优先 card-title div, 其次 img alt, 再次 title 属性
                title = ''
                tm = self._re_card_title.search(chunk)
                if tm:
                    title = tm.group(1).strip()
                if not title:
                    am = self._re_img_alt.search(chunk)
                    if am:
                        title = am.group(1).strip()
                if not title:
                    tm2 = re.search(r'title="([^"]+)"', chunk)
                    if tm2:
                        title = tm2.group(1).strip()
                if not title:
                    continue

                pic_m = self._re_data_original.search(chunk)
                pic = self._proxy_pic(self._fix_url(pic_m.group(1))) if pic_m else ''

                note_m = self._re_item_note.search(chunk)
                remark = note_m.group(1).strip() if note_m else ''

                results.append({
                    "vod_id": vod_id,
                    "vod_name": title,
                    "vod_pic": pic,
                    "vod_remarks": remark,
                })
        else:
            # ---------------- 模式A: module-poster-item (首页/分类页) ----------------
            for m in self._re_detail_anchor.finditer(html):
                vod_id = m.group(2)
                if vod_id in seen:
                    continue
                seen.add(vod_id)

                title = m.group(3).strip()
                if not title:
                    continue

                ctx_start = max(0, m.start() - 400)
                ctx_end = min(len(html), m.end() + 400)
                chunk = html[ctx_start:ctx_end]

                # 标题兜底: 如果 title 属性过短, 优先用显示标题 div
                div_title_m = self._re_poster_title.search(chunk)
                if div_title_m:
                    div_title = div_title_m.group(1).strip()
                    if div_title and len(div_title) > len(title):
                        title = div_title

                pic_m = self._re_data_original.search(chunk)
                pic = self._proxy_pic(self._fix_url(pic_m.group(1))) if pic_m else ''

                remark_m = self._re_item_text.search(chunk)
                if not remark_m:
                    remark_m = self._re_item_note.search(chunk)
                remark = remark_m.group(1).strip() if remark_m else ''

                results.append({
                    "vod_id": vod_id,
                    "vod_name": title,
                    "vod_pic": pic,
                    "vod_remarks": remark,
                })

            # 模式A兜底: 无 title 属性的 poster 链接
            if not results:
                for m in self._re_detail_anchor_no_title.finditer(html):
                    vod_id = m.group(2)
                    if vod_id in seen:
                        continue
                    seen.add(vod_id)

                    full_tag = m.group(0)
                    tm = re.search(r'title="([^"]*)"', full_tag)
                    title = tm.group(1).strip() if tm else ''
                    if not title:
                        inner = re.sub(r'<[^>]+>', '', full_tag).strip()
                        title = inner
                    if not title:
                        continue

                    ctx_start = max(0, m.start() - 400)
                    ctx_end = min(len(html), m.end() + 400)
                    chunk = html[ctx_start:ctx_end]

                    pic_m = self._re_data_original.search(chunk)
                    pic = self._proxy_pic(self._fix_url(pic_m.group(1))) if pic_m else ''

                    remark_m = self._re_item_text.search(chunk)
                    remark = remark_m.group(1).strip() if remark_m else ''

                    results.append({
                        "vod_id": vod_id,
                        "vod_name": title,
                        "vod_pic": pic,
                        "vod_remarks": remark,
                    })

        return results

    def _extract_pagecount(self, html, default_pg=1):
        pagecount = default_pg
        for m in self._re_pagination.finditer(html):
            pagecount = max(pagecount, int(m.group(1)))
        for m in self._re_search_pg.finditer(html):
            pagecount = max(pagecount, int(m.group(1)))
        tm = self._re_total.search(html)
        if tm:
            val = int(tm.group(1))
            if val < 500:
                pagecount = max(pagecount, val)
        return pagecount

    # ===================== 首页 =====================
    def homeContent(self, filter):
        resp = self._fetch(self.site_url + "/")
        video_list = []
        if resp:
            video_list = self._parse_list_regex(resp.text)[:36]
        return {
            "class": self.categories,
            "list": video_list,
            "filters": self.filters,
        }

    def homeVideoContent(self):
        resp = self._fetch(self.site_url + "/")
        video_list = []
        if resp:
            video_list = self._parse_list_regex(resp.text)[:20]
        return {"list": video_list}

    # ===================== 二级分类 =====================
    def categoryContent(self, tid, pg, filter, extend):
        page = int(pg) if pg else 1

        ext = {}
        if extend:
            if isinstance(extend, str):
                try:
                    ext = json.loads(extend)
                except Exception:
                    ext = {}
            elif isinstance(extend, dict):
                ext = extend

        cls = ext.get('class', '')
        area = ext.get('area', '')
        by = ext.get('by', '')

        # MacCMS V10 筛选URL格式: /vod/show/class/xxx/area/xxx/by/xxx/id/xxx/page/xxx.html
        parts = []
        if cls:
            parts.append(f"class/{urllib.parse.quote(cls)}")
        if area:
            parts.append(f"area/{urllib.parse.quote(area)}")
        if by:
            parts.append(f"by/{by}")
        parts.append(f"id/{tid}")
        parts.append(f"page/{page}")
        url = f"{self.site_url}/index.php/vod/show/" + "/".join(parts) + ".html"

        resp = self._fetch(url)
        if not resp:
            return {"list": [], "page": page, "pagecount": 1,
                    "limit": 30, "total": 0}

        html = resp.text
        video_list = self._parse_list_regex(html)
        pagecount = self._extract_pagecount(html, page)
        total = len(video_list) * pagecount if video_list else 0

        return {
            "list": video_list, "page": page,
            "pagecount": pagecount, "limit": 30, "total": total,
        }

    # ===================== 详情 =====================
    def detailContent(self, ids):
        if not ids:
            return {"list": []}
        vod_id = str(ids[0])
        url = f"{self.site_url}/index.php/vod/detail/id/{vod_id}.html"
        resp = self._fetch(url)
        if not resp:
            return {"list": []}

        html = resp.text

        # ---- 标题 ----
        vod_name = vod_id
        m = self._re_title_h1.search(html)
        if m:
            vod_name = m.group(1).strip()
        else:
            m = self._re_title_tag.search(html)
            if m:
                vod_name = m.group(1).split('-')[0].split('在线')[0].strip()

        # ---- 封面图 (优先 data-original, 兜底 src; 统一走代理) ----
        vod_pic = ''
        pm = self._re_data_original.search(html)
        if not pm:
            pm = self._re_img_src.search(html)
        if pm:
            vod_pic = self._proxy_pic(self._fix_url(pm.group(1)))

        # ---- 简介 ----
        vod_content = ''
        cm = self._re_content.search(html)
        if cm:
            vod_content = re.sub(r'<[^>]+>', '', cm.group(1)).strip()
        if not vod_content:
            vod_content = '暂无剧情'

        # ---- 导演 ----
        vod_director = ''
        dm = self._re_director.search(html)
        if dm:
            raw = dm.group(1)
            names = re.findall(r'>([^<]+)</a>', raw)
            if names:
                vod_director = ','.join(names)
            else:
                vod_director = re.sub(r'<[^>]+>', '', raw).strip()

        # ---- 主演 ----
        vod_actor = ''
        am = self._re_actor.search(html)
        if am:
            raw = am.group(1)
            names = re.findall(r'>([^<]+)</a>', raw)
            if names:
                vod_actor = ','.join(names)
            else:
                vod_actor = re.sub(r'<[^>]+>', '', raw).strip()

        # ---- 年份 / 地区 ----
        vod_year = ''
        vod_area = ''
        for tm in self._re_year_area.finditer(html):
            key = tm.group(1)
            val = urllib.parse.unquote(tm.group(2))
            name = tm.group(3)
            if key == 'year':
                vod_year = name
            elif key == 'area':
                vod_area = name

        # ---- 播放列表 ----
        play_from_list, play_url_list = self._parse_playlist(html, vod_id)

        if not play_url_list:
            play_from_list.append('默认线路')
            play_url_list.append(
                f"第01集${self.site_url}/index.php/vod/play/id/{vod_id}/sid/1/nid/1.html"
            )

        result = [{
            "vod_id": vod_id,
            "vod_name": vod_name,
            "vod_pic": vod_pic,
            "vod_content": vod_content,
            "vod_actor": vod_actor,
            "vod_director": vod_director,
            "vod_area": vod_area,
            "vod_year": vod_year,
            "vod_play_from": '$$$'.join(play_from_list),
            "vod_play_url": '$$$'.join(play_url_list),
        }]
        return {"list": result}

    def _parse_playlist(self, html, vod_id):
        """解析播放列表: 线路名 + 选集"""
        # 1. 线路名
        line_names = self._re_line_name.findall(html)

        # 2. 按 sid 分组提取选集
        groups = {}
        seen_keys = set()
        for m in self._re_play_link.finditer(html):
            href, sid, nid = m.groups()
            key = (sid, nid)
            if key in seen_keys:
                continue
            seen_keys.add(key)
            ep_name = f"第{int(nid):02d}集"
            groups.setdefault(sid, []).append(
                f"{ep_name}${self._fix_url(href)}"
            )

        # 3. 按 sid 排序, 映射线路名
        sorted_sids = sorted(groups.keys(),
                             key=lambda x: int(x) if str(x).isdigit() else 0)

        play_from_list = []
        play_url_list = []
        for idx, sid in enumerate(sorted_sids):
            name = line_names[idx] if idx < len(line_names) else f"线路{idx + 1}"
            play_from_list.append(name)
            play_url_list.append('#'.join(groups[sid]))

        return play_from_list, play_url_list

    # ===================== 搜索 =====================
    def searchContent(self, key, quick, pg="1"):
        page = int(pg) if pg else 1
        encoded = urllib.parse.quote(key)
        url = (
            f"{self.site_url}/index.php/vod/search/"
            f"page/{page}/wd/{encoded}.html"
        )
        resp = self._fetch(url)
        if not resp:
            return {"list": [], "page": page, "pagecount": 1}

        html = resp.text
        video_list = self._parse_list_regex(html)
        pagecount = self._extract_pagecount(html, page)

        return {"list": video_list, "page": page, "pagecount": pagecount}

    # ===================== 播放 =====================
    def playerContent(self, flag, id, vipFlags):
        """播放解析: 自动检测 m3u8 可达性, 失败则切换其他线路"""
        if id.startswith('http'):
            play_url = id
        elif id.startswith('/'):
            play_url = self.site_url + id
        else:
            play_url = self.site_url + '/' + id

        parts_m = self._re_play_url_parts.search(play_url)
        vod_id = parts_m.group(1) if parts_m else None
        current_sid = int(parts_m.group(2)) if parts_m else None
        nid = parts_m.group(3) if parts_m else None

        resp = self._fetch(play_url)
        if not resp:
            return {"parse": 1, "url": play_url, "header": self.play_headers}

        html = resp.text
        m3u8_url = self._extract_m3u8_from_html(html)

        if m3u8_url:
            if self._check_m3u8_alive(m3u8_url):
                return {"parse": 0, "url": m3u8_url,
                        "header": self.play_headers}
            if vod_id and current_sid and nid:
                alt_url = self._try_alternative_sources(vod_id, nid, current_sid)
                if alt_url:
                    return {"parse": 0, "url": alt_url,
                            "header": self.play_headers}
            return {"parse": 0, "url": m3u8_url,
                    "header": self.play_headers}

        return {"parse": 1, "url": play_url, "header": self.play_headers}

    def _extract_m3u8_from_html(self, html):
        """从播放页 HTML 提取 m3u8 地址 (player变量优先)"""
        # 方法1: player_xxx 变量中的url字段
        m = self._re_player_var.search(html)
        if m:
            player_json = m.group(1)
            url_m = self._re_m3u8_in_json.search(player_json)
            if url_m:
                return url_m.group(1).replace('\\/', '/')

        # 方法2: 直接匹配m3u8链接
        m2 = self._re_m3u8_direct.search(html)
        if m2:
            return m2.group(0)

        # 方法3: data-play属性
        m3 = re.search(r'data-play="([^"]+)"', html)
        if m3:
            url = m3.group(1)
            if url.startswith('http') and '.m3u8' in url:
                return url

        return None

    def _try_alternative_sources(self, vod_id, nid, exclude_sid):
        """尝试其他线路的播放页, 返回首个可达的 m3u8"""
        detail_url = f"{self.site_url}/index.php/vod/detail/id/{vod_id}.html"
        resp = self._fetch(detail_url)
        if not resp:
            return None

        all_sids = set(self._re_all_sids.findall(resp.text))
        other_sids = sorted(
            [int(s) for s in all_sids if int(s) != exclude_sid]
        )

        for sid in other_sids:
            alt_play_url = (
                f"{self.site_url}/index.php/vod/play/"
                f"id/{vod_id}/sid/{sid}/nid/{nid}.html"
            )
            alt_resp = self._fetch(alt_play_url)
            if not alt_resp:
                continue
            m3u8 = self._extract_m3u8_from_html(alt_resp.text)
            if m3u8 and self._check_m3u8_alive(m3u8):
                return m3u8
        return None

    # ===================== 其他 =====================
    def isVideoFormat(self, url):
        return '.m3u8' in url

    def manualVideoCheck(self):
        return False
