# -*- coding: utf-8 -*-
"""
小唐视频 (xiaotie8.com) - TVBox Spider 插件
站点特性：Next.js 14 App Router + RSC (React Server Components)
播放地址：/cdn/video/{hash}.m3u8 302 自动签发签名，直链可用
反爬：极轻，仅 600/分钟限流，无验证码/加密/会话校验
"""

import re
import json
import time
import math
import requests
import urllib.parse
from datetime import datetime
from bs4 import BeautifulSoup

try:
    from base.spider import Spider
except ImportError:
    # 本地调试兜底
    class Spider:
        def init(self, extend=""):
            pass

class Spider(Spider):
    # ========== 站点基础配置 ==========
    SITE_URL = "https://xiaotie8.com"
    COVER_BASE = "https://cdn.g3ejjm8m.com"
    UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
          "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
    
    # 请求节流：最小间隔(秒)
    MIN_INTERVAL = 0.6
    # 限流冷却：被限流后的初始冷却秒数，后续翻倍
    BLOCK_BASE = 2
    BLOCK_MAX = 30
    # 播放地址缓存(秒)
    PLAY_CACHE_TTL = 30 * 60

    # 默认分类兜底(init时会动态刷新)
    DEFAULT_CLASSES = [
        {"type_id": "tags-e8e41081", "type_name": "剧情片"},
        {"type_id": "tags-32cfcae1", "type_name": "动作片"},
        {"type_id": "tags-c1085cf0", "type_name": "喜剧片"},
        {"type_id": "tags-a5105c10", "type_name": "恐怖片"},
        {"type_id": "tags-816b89d0", "type_name": "悬疑片"},
        {"type_id": "tags-4c7859ef", "type_name": "惊悚片"},
        {"type_id": "tags-72b2963f", "type_name": "战争片"},
        {"type_id": "tags-45a99202", "type_name": "爱情片"},
        {"type_id": "tags-f496793e", "type_name": "歌舞片"},
        {"type_id": "tags-2a9e9e2f", "type_name": "冒险片"},
        {"type_id": "tags-746db979", "type_name": "犯罪片"},
        {"type_id": "tags-42d11411", "type_name": "科幻片"},
        {"type_id": "tags-68102803", "type_name": "网络电影片"},
        {"type_id": "tags-f100b45d", "type_name": "奇幻片"},
        {"type_id": "tags-2a8e9003", "type_name": "灾难片"},
        {"type_id": "tags-d61cf726", "type_name": "动画电影片"},
        {"type_id": "tags-e3ff2e87", "type_name": "同性片"},
        {"type_id": "tags-2ba58e3f", "type_name": "纪录片"},
        {"type_id": "tags-d92a4ec8", "type_name": "经典片"},
        {"type_id": "tags-0ea0bbe5", "type_name": "男男电影"},
        {"type_id": "tags-037310b3", "type_name": "百合电影"},
        {"type_id": "tags-8a0ee0ce", "type_name": "国产剧"},
        {"type_id": "tags-7b77dff8", "type_name": "日剧"},
        {"type_id": "tags-a8d6f0b2", "type_name": "欧美剧"},
        {"type_id": "tags-c977d17a", "type_name": "港剧"},
        {"type_id": "tags-6a628831", "type_name": "台剧"},
        {"type_id": "tags-6e7c374c", "type_name": "新马剧"},
        {"type_id": "tags-44baaddd", "type_name": "港台动漫"},
        {"type_id": "tags-2cbc5934", "type_name": "强者"},
        {"type_id": "tags-3fb1e0a1", "type_name": "逆袭"},
    ]

    def getName(self):
        return "小唐视频"

    def init(self, extend=""):
        """初始化：构建Session，动态拉取分类"""
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": self.UA,
            "Referer": self.SITE_URL + "/",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        })

        # 节流状态
        self._last_req_ts = 0.0
        self._block_until = 0.0
        self._block_seconds = self.BLOCK_BASE

        # 播放地址缓存: url -> (expire_ts, final_url)
        self._play_cache = {}

        # 分类缓存
        self.classes = list(self.DEFAULT_CLASSES)
        self._refresh_categories()

    # ========== 网络请求层 ==========
    def _apply_req_delay(self):
        """节流控制，防止触发限流"""
        now = time.time()
        # 冷却中
        if now < self._block_until:
            wait = self._block_until - now
            time.sleep(wait)
        # 最小间隔
        delta = now - self._last_req_ts
        if delta < self.MIN_INTERVAL:
            time.sleep(self.MIN_INTERVAL - delta)
        self._last_req_ts = time.time()

    def _enter_block(self):
        """进入限流冷却状态"""
        self._block_until = time.time() + self._block_seconds
        self._block_seconds = min(self._block_seconds * 2, self.BLOCK_MAX)

    def _leave_block(self):
        """请求成功，重置冷却"""
        self._block_seconds = self.BLOCK_BASE

    def _get(self, url, retries=3):
        """带重试和冷却的GET请求"""
        for attempt in range(retries):
            self._apply_req_delay()
            try:
                r = self.session.get(url, timeout=15, allow_redirects=True)
                if r.status_code == 429 or r.status_code == 503:
                    self._enter_block()
                    continue
                r.encoding = 'utf-8'
                self._leave_block()
                return r.text
            except Exception:
                if attempt == retries - 1:
                    raise
                time.sleep(1 + attempt)
        return ""

    # ========== 分类动态刷新 ==========
    def _refresh_categories(self):
        """从 /tags 页拉取最新分类映射"""
        try:
            html = self._get(self.SITE_URL + "/tags")
            rsc = self._parse_rsc(html)
            # 在RSC中找 tag slug->name 对，格式："slug":"tags-xxx","name":"剧情片"
            pairs = re.findall(
                r'"slug":"(tags-[0-9a-f]{8})","name":"([^"]+)"',
                rsc
            )
            if pairs:
                seen = set()
                new_classes = []
                for slug, name in pairs:
                    if slug in seen or not name:
                        continue
                    seen.add(slug)
                    new_classes.append({"type_id": slug, "type_name": name})
                if new_classes:
                    self.classes = new_classes
        except Exception:
            pass  # 失败就用默认分类

    # ========== RSC (React Server Components) 解析 ==========
    @staticmethod
    def _js_string_unescape(s):
        """解码 __next_f.push 里 JS 字符串的转义序列"""
        out = []
        i = 0
        n = len(s)
        while i < n:
            ch = s[i]
            if ch == '\\' and i + 1 < n:
                nxt = s[i + 1]
                if nxt == '"':
                    out.append('"'); i += 2; continue
                elif nxt == '\\':
                    out.append('\\'); i += 2; continue
                elif nxt == '/':
                    out.append('/'); i += 2; continue
                elif nxt == 'n':
                    out.append('\n'); i += 2; continue
                elif nxt == 'r':
                    out.append('\r'); i += 2; continue
                elif nxt == 't':
                    out.append('\t'); i += 2; continue
                elif nxt == 'b':
                    out.append('\b'); i += 2; continue
                elif nxt == 'f':
                    out.append('\f'); i += 2; continue
                elif nxt == 'u' and i + 5 < n:
                    hex4 = s[i+2:i+6]
                    try:
                        out.append(chr(int(hex4, 16)))
                        i += 6; continue
                    except ValueError:
                        pass
                # 其他转义原样输出
                out.append(ch)
                i += 1
            else:
                out.append(ch)
                i += 1
        return ''.join(out)

    def _parse_rsc(self, html):
        """从HTML中提取所有RSC chunk并拼接成完整文本"""
        chunks = re.findall(r'self\.__next_f\.push\(\[1,"(.*?)"\]\)', html, re.S)
        return ''.join(self._js_string_unescape(c) for c in chunks)

    # ========== 视频对象提取 ==========
    @staticmethod
    def _extract_json_objects(merged, anchor='"content_type":"video"', max_obj_len=30000):
        """从RSC文本中以anchor为锚点，花括号栈匹配切出所有JSON视频对象"""
        items = []
        i = 0
        while True:
            i = merged.find(anchor, i)
            if i < 0:
                break
            start = merged.rfind('{', max(0, i - 6000), i)
            if start < 0:
                i += len(anchor)
                continue

            depth = 0
            end = -1
            in_str = False
            esc = False
            scan_end = min(start + max_obj_len, len(merged))
            for j in range(start, scan_end):
                ch = merged[j]
                if in_str:
                    if esc:
                        esc = False
                    elif ch == '\\':
                        esc = True
                    elif ch == '"':
                        in_str = False
                else:
                    if ch == '"':
                        in_str = True
                    elif ch == '{':
                        depth += 1
                    elif ch == '}':
                        depth -= 1
                        if depth == 0:
                            end = j + 1
                            break

            if end > 0:
                try:
                    obj = json.loads(merged[start:end])
                    items.append(obj)
                except Exception:
                    pass
                i = end
            else:
                i += len(anchor)
        return items

    @staticmethod
    def _extract_pagination(merged):
        """提取分页元信息"""
        m = re.search(r'"page":(\d+),"limit":(\d+),"total":(\d+),"totalPages":(\d+)', merged)
        if m:
            return {
                "page": int(m.group(1)),
                "limit": int(m.group(2)),
                "total": int(m.group(3)),
                "totalPages": int(m.group(4)),
            }
        return {}

    # ========== 数据组装 ==========
    def _cover_url(self, path):
        """补全封面URL"""
        if not path:
            return ""
        if path.startswith("http"):
            return path
        if path.startswith("//"):
            return "https:" + path
        if path.startswith("/"):
            return self.COVER_BASE + path
        return self.COVER_BASE + "/" + path

    def _m3u8_url(self, path):
        """补全m3u8 URL"""
        if not path:
            return ""
        if path.startswith("http"):
            return path
        if path.startswith("/"):
            return self.SITE_URL + path
        return self.SITE_URL + "/" + path

    @staticmethod
    def _clean_title(title):
        """标题清洗：去除SEO副标题(冒号后半部分可选)、去空格"""
        if not title:
            return ""
        title = title.strip()
        return title

    def _to_vod(self, it):
        """把原始JSON视频对象转成TVBox vod格式"""
        ed = it.get("extra_data") or {}
        links = ed.get("links") or []
        tags = [t.get("name", "") for t in (it.get("tags") or [])]

        # 拼装集数：name$url#name$url...
        episodes = []
        for lk in links:
            name = (lk.get("name") or "").strip() or "播放"
            m3u8 = lk.get("m3u8_url") or ""
            if not m3u8:
                continue
            episodes.append(f"{name}${self._m3u8_url(m3u8)}")
        play_url = "#".join(episodes)

        # 备注：分类名 / 更新状态
        remark_parts = []
        cat_name = ed.get("cat_name", "")
        if cat_name:
            remark_parts.append(cat_name)
        elif tags:
            remark_parts.append(tags[0])
        if ed.get("update_status") == "1":
            remark_parts.append("更新中")
        remark = " · ".join(p for p in remark_parts if p)

        return {
            "vod_id": it.get("slug", ""),
            "vod_name": self._clean_title(it.get("title", "")),
            "vod_pic": self._cover_url(it.get("cover_image", "")),
            "vod_remarks": remark,
            "vod_year": str(ed.get("issue_date", "") or ""),
            "vod_director": ed.get("director", "") or "",
            "vod_actor": ed.get("actor", "") or "",
            "vod_content": (it.get("excerpt") or "").strip(),
            "vod_play_from": "小唐视频",
            "vod_play_url": play_url,
        }

    # ========== TVBox 标准接口 ==========
    def homeContent(self, filter):
        """首页：返回分类列表 + 首页推荐 + 过滤器(无筛选条件，filters为空)"""
        result = {"class": self.classes, "list": [], "filters": {}}
        try:
            html = self._get(f"{self.SITE_URL}/?page=1")
            merged = self._parse_rsc(html)
            items = self._extract_json_objects(merged)
            result["list"] = [self._to_vod(it) for it in items[:24]]
        except Exception:
            pass
        return result

    def homeVideoContent(self):
        """首页推荐视频"""
        result = {"list": []}
        try:
            html = self._get(f"{self.SITE_URL}/?page=1")
            merged = self._parse_rsc(html)
            items = self._extract_json_objects(merged)
            result["list"] = [self._to_vod(it) for it in items[:24]]
        except Exception:
            pass
        return result

    def categoryContent(self, tid, pg, filter, extend):
        """分类页: tid=tags-xxx, pg=页码"""
        result = {"page": int(pg), "pagecount": 1, "limit": 20, "total": 0, "list": []}
        try:
            page = int(pg) if pg else 1
            url = f"{self.SITE_URL}/tag/{tid}?page={page}"
            html = self._get(url)
            merged = self._parse_rsc(html)
            items = self._extract_json_objects(merged)
            pager = self._extract_pagination(merged)

            result["list"] = [self._to_vod(it) for it in items]
            result["page"] = page
            result["pagecount"] = pager.get("totalPages", 1)
            result["limit"] = pager.get("limit", 20)
            result["total"] = pager.get("total", 0)
        except Exception:
            pass
        return result

    def searchContent(self, key, quick=False, pg=1):
        """搜索"""
        result = {"page": int(pg), "pagecount": 1, "limit": 20, "total": 0, "list": []}
        try:
            page = int(pg) if pg else 1
            q = urllib.parse.quote(key)
            url = f"{self.SITE_URL}/search?q={q}&page={page}"
            html = self._get(url)
            merged = self._parse_rsc(html)
            items = self._extract_json_objects(merged)
            pager = self._extract_pagination(merged)

            # 相关度排序：完全匹配/开头匹配/包含优先
            def score(v):
                t = v.get("title", "")
                k = key
                if t == k:
                    return 0
                if t.startswith(k):
                    return 1
                if k in t:
                    return 2
                return 3
            items.sort(key=score)

            result["list"] = [self._to_vod(it) for it in items]
            result["page"] = page
            result["pagecount"] = pager.get("totalPages", 1)
            result["limit"] = pager.get("limit", 20)
            result["total"] = pager.get("total", 0)
        except Exception:
            pass
        return result

    def detailContent(self, ids):
        """
        详情页。
        说明：列表页已经返回完整的 extra_data.links 和 excerpt，
        所以无需再请求详情页，直接从ids(即slug)反查数据。
        但TVBox传入的ids是vod_id(即slug)，我们这里再抓一次详情页，
        保证拿到最全的简介和标签数据。
        """
        if not ids:
            return {"list": []}
        vod_id = ids[0] if isinstance(ids, list) else ids
        vod = {}
        try:
            # 详情页URL: /article/{slug}，slug就是 "video-标题-hash"
            url = f"{self.SITE_URL}/article/{urllib.parse.quote(vod_id)}"
            html = self._get(url)
            merged = self._parse_rsc(html)
            items = self._extract_json_objects(merged)
            if items:
                vod = self._to_vod(items[0])
                # 如果标题清洗后为空或过短，尝试从<title>补全
                if not vod.get("vod_name"):
                    title_m = re.search(r"<title>([^<]+)</title>", html)
                    if title_m:
                        t = title_m.group(1).replace("-小唐视频", "").replace("-免费电影观看", "").strip()
                        vod["vod_name"] = t
            else:
                # 兜底：返回空对象避免崩溃
                vod = {
                    "vod_id": vod_id,
                    "vod_name": vod_id,
                    "vod_pic": "",
                    "vod_remarks": "",
                    "vod_content": "",
                    "vod_play_from": "小唐视频",
                    "vod_play_url": "",
                }
        except Exception:
            vod = {
                "vod_id": vod_id,
                "vod_name": vod_id,
                "vod_pic": "",
                "vod_remarks": "",
                "vod_content": "",
                "vod_play_from": "小唐视频",
                "vod_play_url": "",
            }
        return {"list": [vod]}

    def _resolve_m3u8(self, url):
        """
        主动跟随302，拿到带sign签名的最终m3u8地址。
        某些壳子可能不自动跟随302，这里提前解出来更稳。
        """
        now = time.time()
        if url in self._play_cache:
            exp, cached = self._play_cache[url]
            if now < exp:
                return cached

        try:
            self._apply_req_delay()
            r = self.session.get(url, timeout=15, allow_redirects=False)
            if r.status_code in (301, 302, 303, 307, 308):
                location = r.headers.get("Location", url)
                if location.startswith("/"):
                    # 相对重定向：一般重定向到CDN是绝对地址，兜底拼一下
                    location = self.SITE_URL + location
                final_url = location
            else:
                final_url = url
        except Exception:
            final_url = url

        self._play_cache[url] = (now + self.PLAY_CACHE_TTL, final_url)
        return final_url

    def playerContent(self, flag, id, vipFlags=None):
        """
        播放接口。
        id 就是 vod_play_url 里 $ 后面的 m3u8 地址（即 /cdn/video/xxx.m3u8 的完整URL）。
        返回直链，parse=0。
        """
        try:
            final_url = self._resolve_m3u8(id)
        except Exception:
            final_url = id

        return {
            "parse": 0,
            "url": final_url,
            "header": json.dumps({
                "User-Agent": self.UA,
                "Referer": self.SITE_URL + "/",
            }, ensure_ascii=False),
            "playUrl": "",
            "jx": 0,
        }


# ========== 本地调试入口 ==========
if __name__ == "__main__":
    s = Spider()
    s.init()

    print("=" * 60)
    print(f"分类数量: {len(s.classes)}")
    for c in s.classes[:5]:
        print(f"  - {c['type_name']}  ({c['type_id']})")
    print("  ...")

    print("\n--- 首页推荐 ---")
    home = s.homeVideoContent()
    for v in home["list"][:5]:
        print(f"  [{v['vod_remarks']}] {v['vod_name']}  集数:{v['vod_play_url'].count('#')+1 if v['vod_play_url'] else 0}")

    print("\n--- 分类页: 国产剧 第1页 ---")
    cat = s.categoryContent("tags-8a0ee0ce", 1, False, {})
    print(f"  共 {cat['total']} 部 / {cat['pagecount']} 页")
    for v in cat["list"][:5]:
        print(f"  [{v['vod_remarks']}] {v['vod_name']}")

    print("\n--- 搜索: 风云 ---")
    sr = s.searchContent("风云", pg=1)
    for v in sr["list"][:5]:
        print(f"  [{v['vod_remarks']}] {v['vod_name']}")

    print("\n--- 详情: 首页第一个 ---")
    if home["list"]:
        first = home["list"][0]
        detail = s.detailContent([first["vod_id"]])
        v = detail["list"][0]
        print(f"  片名: {v['vod_name']}")
        print(f"  导演: {v['vod_director']}")
        print(f"  演员: {v['vod_actor']}")
        print(f"  年份: {v['vod_year']}")
        print(f"  简介: {v['vod_content'][:80]}...")
        first_ep = v["vod_play_url"].split("#")[0] if v["vod_play_url"] else ""
        if first_ep:
            ep_name, ep_url = first_ep.split("$", 1)
            print(f"\n--- 播放解析: {ep_name} ---")
            pc = s.playerContent("小唐视频", ep_url)
            print(f"  最终地址: {pc['url']}")
            print(f"  parse: {pc['parse']}")
