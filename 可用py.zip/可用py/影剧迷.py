#!/usr/bin/env python3
# coding=utf-8
"""
影剧迷 (yingjumi.cc) —— OK壳子 / 影视仓 / TVBox Python 爬虫 (T4 直出)

站点说明:
  yingjumi.cc 是基于 MacCMS (苹果CMS) + shoutu45 模板的影视站。
  经实测分析, 关键链路如下:

  分类导航 (type_id 直接复用站点 vodtype 编号, 翻页用 /vodtype/{tid}-{N}.html):
    1=电影 2=动漫 3=电视剧 4=短剧 19=Netflix电影 33=4K电影 42=Netflix自制剧

  列表卡片 (public-list-box):
    <div class="public-list-box public-pic-b">
      <div class="public-list-div public-list-bj">
        <a class="public-list-exp" href="/voddetail/{ID}.html" title="{标题}">
          <img class="lazy lazy1 gen-movie-img mask-0" ... data-src="{海报URL}" .../>
          <span class="public-list-prb ...">{备注/状态}</span>

  详情页 -> 线路 / 选集:
    - 线路:   <div class="anthology-tab ..."><div class="swiper-wrapper">
                <a class="swiper-slide"><i...></i>&nbsp;{线路名}<span class="badge">{N}</span></a>
    - 选集:   <ul class="anthology-list-play size">
                <li class="box border"><a href="/vodplay/{ID}-{S}-{E}.html">{第N集}</a></li>
    说明: 播放地址格式 /vodplay/{视频ID}-{线路S}-{集号E}.html ; S 从 1 开始。

  播放解析 (playerContent, parse=0 直出):
    抓播放页 -> 抽取 player_aaaa JSON (以 </script> 为界) -> 取 url 字段:
      1) url 已是 .m3u8/.mp4 -> 直接回传 (如 vip.dytt-see.com/.../index.m3u8)
      2) url 是分享页 -> 再抓一层抽取内嵌 m3u8 (兼容 const url= / var main= 写法)

部署见文件末尾说明。
"""

import gzip
import json
import re
import sys
import urllib.parse
import urllib.request
from html import unescape

sys.path.append('..')

# 壳子运行环境提供 base.spider (OK壳子 / 影视仓 / TVBox 均内置)
from base.spider import Spider as BaseSpider


def _log(msg):
    sys.stderr.write('[yingjumi] ' + str(msg) + '\n')


SITE = 'https://yingjumi.cc'
UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')

# 分类导航 (type_id 直接复用站点真实 vodtype 编号)
_C = lambda tid, name: {'type_id': tid, 'type_name': name}
CATEGORIES = [
    _C('1', '电影'),
    _C('2', '动漫'),
    _C('3', '电视剧'),
    _C('4', '短剧'),
    _C('19', 'Netflix电影'),
    _C('33', '4K电影'),
    _C('42', 'Netflix自制剧'),
]


class Spider(BaseSpider):
    # ==================== 生命周期 ====================
    def init(self, extend=''):
        self.site = SITE
        self.headers = {
            'User-Agent': UA,
            'Referer': SITE + '/',
            'Accept-Language': 'zh-CN,zh;q=0.9',
        }
        try:
            if extend:
                ext = extend.strip()
                if ext.startswith('{'):
                    ext = json.loads(ext).get('site', '')
                if ext.startswith('http'):
                    self.site = ext.rstrip('/')
        except Exception as e:
            _log('init 解析 extend 失败: %s' % e)
        return self

    def getName(self):
        return '影剧迷'

    def isVideoFormat(self, url):
        return bool(re.search(r'\.(m3u8|mp4|mkv|flv|avi|ts)(\?|$)', str(url), re.I))

    def manualVideoCheck(self):
        return False

    # ==================== 内部工具 ====================
    def _abs(self, url):
        if not str(url).startswith('http'):
            return self.site + url
        return url

    def _get(self, url, timeout=20):
        """抓取页面, 自动处理 gzip; 相对路径补全站点前缀。"""
        url = self._abs(url)
        req = urllib.request.Request(url, headers=self.headers)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = resp.read()
            enc = resp.headers.get('Content-Encoding', '')
            if 'gzip' in enc:
                data = gzip.decompress(data)
            return data.decode('utf-8', 'ignore')

    @staticmethod
    def _is_ad(url):
        u = (url or '').lower()
        return any(d in u for d in ('doubleclick', 'googletag', 'cnzz', 'z_stat',
                                    '/ads/', 'analytics', 'umeng', 'matomo'))

    # ==================== 列表解析 ====================
    @staticmethod
    def _card_pic(inner):
        """从卡片内容取海报: 优先 data-src, 否则非占位 src。"""
        pm = re.search(r'data-src="([^"]+)"', inner)
        if not pm or pm.group(1).startswith('data:'):
            pm = re.search(r'\bsrc="([^"]+)"', inner)
        if pm:
            return unescape(pm.group(1)).strip()
        return ''

    def _parse_list(self, html):
        """解析 public-list-box 卡片 -> [{vod_id, vod_name, vod_pic, vod_remarks}]"""
        items = {}
        # 整段 <a class="public-list-exp">...</a> 再细拆属性, 兼容性最好
        for m in re.finditer(
                r'<a\s+[^>]*class="public-list-exp"[^>]*>.*?</a>', html, re.S):
            block = m.group(0)
            hm = re.search(r'href="(/voddetail/(\d+)\.html)"', block)
            if not hm:
                continue
            href, vid = hm.group(1), hm.group(2)
            if vid in items:
                continue
            # 标题: 优先 a 的 title 属性, 否则 img 的 alt
            name = ''
            tm = re.search(r'\btitle="([^"]*)"', block)
            if tm:
                name = unescape(tm.group(1)).strip()
            if not name:
                am = re.search(r'\balt="([^"]*)"', block)
                if am:
                    name = unescape(am.group(1)).replace('封面图', '').strip()
            # 海报
            pic = self._card_pic(block)
            # 备注 (状态/清晰度)
            remark = ''
            rm = re.search(r'class="public-list-prb[^"]*">([^<]*)', block)
            if rm:
                remark = rm.group(1).strip()
            if not name and not pic:
                continue
            items[vid] = {
                'vod_id': href,
                'vod_name': name,
                'vod_pic': pic,
                'vod_remarks': remark,
            }
        return list(items.values())

    @staticmethod
    def _parse_pagecount(html, tid, default=1):
        nums = [int(x) for x in re.findall(r'vodtype/%s-(\d+)\.html' % re.escape(tid), html)]
        return max(nums) if nums else default

    # ==================== 首页 ====================
    def homeContent(self, filter):
        html = self._get('/')
        return {
            'class': [dict(c) for c in CATEGORIES],
            'list': self._parse_list(html),
            'filters': {},
        }

    # ==================== 首页推荐 (羊壳/海阔兼容) ====================
    def homeVideoContent(self):
        return {'list': self._parse_list(self._get('/'))}

    # ==================== 分类 / 列表 ====================
    def categoryContent(self, tid, pg, filter, extend):
        pg = int(pg) if str(pg).isdigit() else 1
        url = '/vodtype/%s.html' % tid if pg <= 1 else '/vodtype/%s-%d.html' % (tid, pg)
        try:
            html = self._get(url)
        except Exception as e:
            _log('categoryContent 抓取失败 %s: %s' % (url, e))
            html = ''
        video_list = self._parse_list(html)
        pagecount = self._parse_pagecount(html, tid)
        return {
            'list': video_list,
            'page': pg,
            'pagecount': pagecount,
            'limit': 24,
            'total': 24 * pagecount,
        }

    # ==================== 搜索 ====================
    def searchContent(self, key, quick, pg='1'):
        pg = int(pg) if str(pg).isdigit() else 1
        try:
            # MacCMS 搜索: GET /vodsearch/-------------.html?wd=关键词
            html = self._get('/vodsearch/-------------.html?wd=' + urllib.parse.quote(key))
        except Exception as e:
            _log('searchContent 抓取失败 %s: %s' % (key, e))
            html = ''
        video_list = self._parse_list(html)
        return {'list': video_list, 'page': pg, 'pagecount': 1, 'limit': 24, 'total': len(video_list)}

    # ==================== 详情 / 选集 ====================
    @staticmethod
    def _source_names(html):
        """从 anthology-tab 提取线路名列表 (顺序即 sid 顺序)。"""
        names = []
        mt = re.search(r'<div class="anthology-tab.*?</div>\s*</div>\s*</div>', html, re.S)
        if not mt:
            return names
        for a in re.findall(r'<a class="swiper-slide">(.*?)</a>', mt.group(0), re.S):
            # 去掉 badge 计数 / 图标 / 空白
            a = re.sub(r'<span[^>]*class="badge"[^>]*>\d+</span>', '', a)
            a = re.sub(r'<[^>]+>', '', a)
            a = a.replace('&nbsp;', '').strip()
            if a:
                names.append(a)
        return names

    def detailContent(self, ids):
        vid = ids[0] if isinstance(ids, (list, tuple)) else ids
        if vid.startswith('http'):
            vid = urllib.parse.urlparse(vid).path
        try:
            html = self._get(vid)
        except Exception as e:
            _log('detailContent 抓取失败 %s: %s' % (vid, e))
            html = ''

        # 标题
        vod_name = ''
        tm = re.search(r'<title>(.*?)</title>', html, re.I)
        if tm:
            vod_name = re.split(r'[_\-|]', tm.group(1))[0].strip().lstrip('《').rstrip('》')

        # 海报: 详情页首张 upload/vod 海报
        vod_pic = ''
        pm = re.search(r'(https?://[^\s"<>]+\.(?:jpg|jpeg|png|webp))', html)
        if pm:
            vod_pic = unescape(pm.group(1)).strip()

        # 简介: 简介 标签后的文本
        vod_content = ''
        cm = re.search(r'简介[：:]?\s*(?:</?[^>]+>)*\s*([^<]{15,500})', html)
        if cm:
            vod_content = unescape(cm.group(1)).strip()

        # 线路 (来源名) 与 选集
        src_names = self._source_names(html)
        # 选集: /vodplay/{ID}-{S}-{E}.html + 标签
        eps = re.findall(
            r'/vodplay/(\d+)-(\d+)-(\d+)\.html"[^>]*>([^<]+)</a>', html)
        from collections import OrderedDict
        by_sid = OrderedDict()
        for _vid, s, _e, label in eps:
            by_sid.setdefault(int(s), []).append(
                (label.strip() or '第%s集' % _e, '/vodplay/%s-%s-%s.html' % (_vid, s, _e)))

        play_from, play_url = [], []
        for idx, sid in enumerate(by_sid.keys(), start=1):
            name = src_names[idx - 1] if idx - 1 < len(src_names) else ('线路%d' % sid)
            line = '#'.join('%s$%s' % (lab, self._abs(u)) for lab, u in by_sid[sid])
            play_from.append(name)
            play_url.append(line)

        if not play_from:
            # 兜底: 详情页无静态选集 -> 单线路指向详情页
            play_from.append('播放')
            play_url.append('第1集$' + self._abs(vid))

        return {'list': [{
            'vod_id': vid,
            'vod_name': vod_name,
            'vod_pic': vod_pic,
            'vod_content': vod_content,
            'vod_play_from': '$$$'.join(play_from),
            'vod_play_url': '$$$'.join(play_url),
        }]}

    # ==================== 播放解析 (parse=0 直出) ====================
    @staticmethod
    def _player_cfg(html):
        """抽取第一个 player_aaaa JSON 块 (以 </script> 为界, 兼容一页多线路)。"""
        m = re.search(r'player_aaaa\s*=\s*(\{.*?\})\s*</script>', html, re.S)
        if not m:
            return None
        try:
            return json.loads(m.group(1))
        except Exception:
            return None

    @staticmethod
    def _extract_m3u8(share_html, share_url):
        """从分享页抽取真 m3u8: 兼容 const url= / var main= / "url": 写法。"""
        mm = re.search(r'(?:const|var|let)\s+\w+\s*=\s*"([^"]*\.(?:m3u8|mp4)[^"]*)"', share_html)
        if not mm:
            mm = re.search(r'[\"\x27]url[\"\x27]\s*:\s*[\"\x27]([^\"\x27]*\.(?:m3u8|mp4)[^\"\x27]*)[\"\x27]', share_html)
        if not mm:
            return ''
        u = mm.group(1).replace('\\/', '/')
        if u.startswith('//'):
            u = 'https:' + u
        if u.startswith('/'):
            u = 'https://' + urllib.parse.urlparse(share_url).netloc + u
        return u

    def playerContent(self, flag, id, vipFlags):
        url = self._abs(str(id))
        try:
            html = self._get(url, timeout=25)
        except Exception as e:
            _log('播放页抓取失败 %s: %s' % (url, e))
            return {'parse': 0, 'url': '', 'header': self.headers}
        cfg = self._player_cfg(html)
        if not cfg or not cfg.get('url'):
            return {'parse': 0, 'url': '', 'header': self.headers}
        media = cfg['url'].replace('\\/', '/')
        header = {'User-Agent': UA, 'Referer': url}
        # 1) 已是直链
        if self.isVideoFormat(media):
            return {'parse': 0, 'url': media, 'header': header}
        # 2) 分享页 -> 再抓一层抽取 m3u8
        try:
            share_html = self._get(media, timeout=25)
        except Exception as e:
            _log('分享页抓取失败 %s: %s' % (media, e))
            return {'parse': 0, 'url': '', 'header': header}
        m3u8 = self._extract_m3u8(share_html, media)
        return {'parse': 0, 'url': m3u8, 'header': header}


# ==================== 部署说明 ====================
# 1. 将本文件放入 OK壳子 / 影视仓 / TVBox 的 spider 目录 (通常命名 spider.py 或 yingjumi.py)。
# 2. 站点换域名时, 在订阅 extend 参数里传: {"site":"https://新域名"} 即可, 无需改代码。
# 3. 列表/详情解析针对 yingjumi.cc 的 MacCMS shoutu45 模板实测校准
#    (public-list-box 卡片 / anthology-tab 线路 / anthology-list-play 选集)。
# 4. 播放为直出 (parse=0): 播放页 player_aaaa 配置直接给出 m3u8;
#    若个别源为分享页, 脚本自动再抓一层抽取真链回传。
# 5. 已验证: 首页 7 大分类、电影/电视剧列表翻页、详情多线路多集、m3u8 直链可达 (合法 HLS)。
# ===================================================
