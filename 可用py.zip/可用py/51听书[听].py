#coding=utf-8
"""
51听书网 TVBox py源 - 听书/评书/相声/有声小说音频站
============================================================
TVBox 原版 py 源专用
用法：TVBox 直接加载本 .py 文件，源名「51听书」
自测：python ting51_pysrc.py test
数据源: https://www.ting51.com/
"""
import json
import re
import sys
from urllib.parse import quote
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

try:
    from base.spider import Spider as _BaseSpider
except Exception:
    _BaseSpider = object

# =====================================================================
SITE = "https://www.ting51.com"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/120.0 Safari/537.36")

_HEADER = {
    "User-Agent": UA,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    "Referer": SITE + "/",
}

_CATS = [
    ("511", "言情"), ("512", "武侠"), ("513", "悬疑"), ("514", "历史"),
    ("515", "军事"), ("516", "评书"), ("517", "相声小品"), ("518", "百家讲坛"),
    ("519", "商业财经"), ("5110", "健康养生"),
]

_PLAYER = {
    "51听书": {"show": "51听书", "des": "m4a音频直连", "ps": "0", "parse": ""},
    "mp3":    {"show": "MP3",    "des": "", "ps": "0", "parse": ""},
    "m4a":    {"show": "M4A",    "des": "", "ps": "0", "parse": ""},
}


# =====================================================================
def _fetch(url, timeout=8):
    try:
        req = Request(url, headers=_HEADER)
        return urlopen(req, timeout=timeout).read().decode("utf-8", "replace")
    except (HTTPError, URLError, Exception):
        return ""


def _clean(s):
    return re.sub(r"\s+", " ", s or "").strip()


def _unescape(s):
    return (s or "").replace("&amp;", "&").replace("&lt;", "<").replace(
        "&gt;", ">").replace("&quot;", '"').replace("&#39;", "'")


def _parse_books(html, limit=40):
    out, seen = [], set()
    for m in re.finditer(r'<div class="stui-vodlist__box">(.*?)</li>', html, re.S):
        block = m.group(1)
        am = re.search(r'<a[^>]+href="/ting/(\d+)\.html"[^>]*>', block)
        if not am:
            continue
        tid = am.group(1)
        if tid in seen:
            continue
        seen.add(tid)
        seg = am.group(0)
        tm = re.search(r'title="([^"]*)"', seg)
        title = _unescape(tm.group(1)).strip() if tm else ""
        pm = re.search(r'data-original="([^"]+)"', seg)
        if not pm:
            pm = re.search(r'src="([^"]+\.(?:jpg|jpeg|png|webp))"', block)
        pic = pm.group(1) if pm else ""
        rmm = re.search(r'<span class="pic-text[^"]*">([^<]*)</span>', block)
        remarks = _clean(_unescape(rmm.group(1))) if rmm else ""
        actm = re.search(
            r'<p class="text[^"]*">(?:<span class="text-muted">[^<]*</span>)?([^<]*)</p>',
            block)
        actor = _clean(_unescape(actm.group(1))) if actm else ""
        out.append({
            "vod_id": tid,
            "vod_name": title,
            "vod_pic": pic,
            "vod_remarks": remarks,
            "vod_actor": actor,
            "vod_year": "",
        })
        if len(out) >= limit:
            break
    return out


def _parse_detail(html, tid):
    code = {}
    m = re.search(r'<h3 class="title">([^<]+)', html)
    code["vod_name"] = _clean(_unescape(m.group(1))) if m else ""
    m = re.search(r'data-original="(https?://[^"]+\.(?:jpg|jpeg|png|webp)[^"]*)"', html)
    if not m:
        m = re.search(r'(https?://[^"\']+\.(?:jpg|jpeg|png|webp)[^"\']*)', html)
    code["vod_pic"] = m.group(1) if m else ""
    m = re.search(r'类型[：:]\s*</span><a href="/list/[^"]*">([^<]+)</a>', html)
    code["type_name"] = _clean(m.group(1)) if m else ""
    m = re.search(r'地区[：:]\s*</span><a[^>]*>([^<]*)</a>', html)
    code["vod_area"] = _clean(m.group(1)) if m else ""
    m = re.search(r'年份[：:]\s*</span><a[^>]*>([^<]*)</a>', html)
    code["vod_year"] = _clean(m.group(1)) if m else ""
    m = re.search(r'主演[：:]\s*</span><a[^>]*>([^<]+)</a>', html)
    code["vod_actor"] = _clean(m.group(1)) if m else ""
    m = re.search(r'导演[：:]\s*</span><a[^>]*>([^<]+)</a>', html)
    code["vod_director"] = _clean(m.group(1)) if m else ""
    m = re.search(r'更新[：:]\s*</span>([^<]+)', html)
    code["vod_pubdate"] = _clean(m.group(1)) if m else ""
    m = re.search(r'class="detail-sketch">([^<]+)', html)
    code["vod_content"] = _clean(_unescape(m.group(1))) if m else ""

    eps = []
    j = html.find("stui-content__playlist")
    ul = html[j:] if j >= 0 else html
    for a in re.finditer(
            r'<a[^>]+href="/play/(\d+)-(\d+)-(\d+)\.html"[^>]*>([^<]+)</a>', ul):
        vid, line, part, name = a.group(1), a.group(2), a.group(3), a.group(4)
        name = _clean(_unescape(name))
        if not name:
            name = "第{}集".format(int(part) + 1)
        eps.append("{}${}/play/{}-{}-{}.html".format(name, SITE, vid, line, part))
    code["vod_play_from"] = "51听书"
    code["vod_play_url"] = "#".join(eps)
    code["vod_remarks"] = "共{}集".format(len(eps)) if eps else ""
    return code


def _page_count(html):
    m = re.search(r'<a[^>]*href="/list/\d+-(\d+)\.html"[^>]*>尾页</a>', html or "")
    return int(m.group(1)) if m else 1


# =====================================================================
class Spider(_BaseSpider):

    config = {"player": dict(_PLAYER), "filter": {}}

    def init(self, extend=""):
        self.config = json.loads(json.dumps(
            self.config or {"player": {}, "filter": {}}))

    def getName(self):
        return "51听书"

    def homeContent(self, filter):
        return {"class": [{"type_id": t, "type_name": n} for t, n in _CATS],
                "filters": {}}

    def homeVideoContent(self):
        html = _fetch(SITE + "/")
        return {"list": _parse_books(html, limit=30)}

    def categoryContent(self, tid, pg, filter=False, extend=""):
        try:
            pg = str(int(pg))
        except (TypeError, ValueError):
            pg = "1"
        url = "{}/list/{}.html".format(SITE, tid) if pg == "1" \
            else "{}/list/{}-{}.html".format(SITE, tid, pg)
        html = _fetch(url)
        books = _parse_books(html, limit=40)
        return {"list": books,
                "page": int(pg),
                "pagecount": max(_page_count(html), int(pg)),
                "limit": 40,
                "total": 99998}

    def detailContent(self, array):
        if isinstance(array, (list, tuple)):
            tid = str(array[0]).strip() if array else ""
        else:
            tid = str(array or "").split(",")[0].strip()
        if not tid.isdigit():
            return {"list": []}
        html = _fetch("{}/ting/{}.html".format(SITE, tid))
        if not html:
            return {"list": []}
        code = _parse_detail(html, tid)
        if not code.get("vod_name") or not code.get("vod_play_url"):
            return {"list": []}
        code["vod_id"] = tid
        self._ensure_players(code.get("vod_play_from", ""))
        return {"list": [code]}

    def _ensure_players(self, play_from):
        players = self.config.setdefault("player", {})
        for flag in re.split(r"\${2,3}", str(play_from or "")):
            flag = flag.strip()
            if flag and flag not in players:
                players[flag] = {"show": flag, "des": "",
                                 "ps": "0", "parse": ""}

    def searchContent(self, key, quick, pg="1"):
        url = "{}/search.php?searchword={}".format(SITE, quote(str(key)))
        html = _fetch(url)
        books = _parse_books(html, limit=40)
        if not books:
            for m in re.finditer(
                    r'<a class="v-thumb stui-vodlist__thumb lazyload" '
                    r'href="/ting/(\d+)\.html" title="([^"]*)" '
                    r'data-original="([^"]+)"[^>]*>', html):
                books.append({"vod_id": m.group(1),
                              "vod_name": _unescape(m.group(2)),
                              "vod_pic": m.group(3),
                              "vod_remarks": "", "vod_actor": "",
                              "vod_year": ""})
                if len(books) >= 40:
                    break
        return {"list": books}

    def playerContent(self, flag, ids, vipFlags=""):
        """TVBox 原版返回格式:
           - header 必须是字符串
           - 只给 url 字段
           - parse=0 表示直连不解析
        播放页 HTML 内嵌明文: var now="https://aod.cos.tx.xmcdn.com/...m4a"
        """
        url = str(ids or "")
        if not url.startswith("http") and str(flag or "").startswith("http"):
            url = str(flag)

        audio = ""
        if url:
            body = _fetch(url)
            for pat in (r'var\s+now\s*=\s*"([^"]+\.(?:m4a|mp3)[^"]*)"',
                        r'var\s+next\s*=\s*"([^"]+\.(?:m4a|mp3)[^"]*)"',
                        r'https?://[^\s"\'<>]+\.(?:m4a|mp3)[^\s"\'<>]*'):
                m = re.search(pat, body)
                if m:
                    audio = m.group(1)
                    break

        if not audio:
            return {"parse": 0, "url": "", "header": "{}"}

        return {
            "parse": 0,
            "url": audio,
            "header": "{}",
        }

    # ---- TVBox 兼容兜底 ----
    def getDependence(self):
        return []

    def localProxy(self, param):
        return [200, "ok", b"", None]

    def liveContent(self, url):
        return ""

    def destroy(self):
        pass

    def isVideoFormat(self, url):
        return False

    def manualVideoCheck(self):
        return True


# =====================================================================
# 自测
# =====================================================================
def _test():
    print("name=51听书 site={}".format(SITE))
    s = Spider()
    s.init("")
    ok = True

    h = s.homeContent(False)
    print("\n== 分类 ==")
    print("分类数:", len(h["class"]), [c["type_name"] for c in h["class"]][:5])
    ok = ok and len(h["class"]) == 10

    c = s.categoryContent("516", "1", False, {})
    print("\n== 评书 第1页 ==")
    print("条数:", len(c["list"]), c["list"][0] if c["list"] else {},
          "| 页数:", c["pagecount"])
    ok = ok and bool(c["list"])

    d = s.detailContent(["102471"])
    v = d["list"][0] if d["list"] else {}
    eps = v.get("vod_play_url", "").split("#")
    print("\n== 详情 102471 ==")
    print("名称:", v.get("vod_name"), "| 章节数:", len(eps) if eps else 0,
          "| 线路:", v.get("vod_play_from"))
    ok = ok and bool(v.get("vod_name")) and bool(eps)

    if eps:
        got = ""
        for i in range(min(5, len(eps))):
            url = eps[i].split("$")[-1]
            pc = s.playerContent("51听书", url, ["4k", "fhd"])
            print("  第{}章 -> {}".format(i, pc.get("url", "")[:110] or "EMPTY"))
            if pc.get("url", "").startswith("http"):
                got = pc["url"]
                break
        print("\n== 播放地址 ==")
        print(got[:150] if got else "(空)")
        ok = ok and bool(got)
    else:
        ok = False

    print("\n自测结果:", "全部通过" if ok else "存在失败")
    return 0 if ok else 1


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "test":
        sys.exit(_test())
    _test()


if __name__ == "__main__":
    main()