# -*- coding: utf-8 -*-
# 36DJ舞曲网 TVBox 爬虫
# 站点架构：帝国CMS，详情页 /play/{id}.html，播放地址在 var info = { "playurl": "..." } 内联 JS
# CDN：http://tn1.72djapp.cn:8399/ + 相对路径（如 2026/3609/04X/17540.m4a）
import sys
sys.path.append('..')
import re
import ssl
import os
import json
import http.cookiejar
import urllib.request
import urllib.parse

try:
    from base.spider import Spider as BaseSpider
except Exception:
    BaseSpider = object


class Spider(BaseSpider):

    def init(self, extend=""):
        self.host = "https://www.36dj.com"
        self.cdn = "http://tn1.72djapp.cn:8399"
        self.cover = "https://img.72djapp.cn/images/style.css"  # 占位，实际用 picsum
        self.cover_tpl = "https://picsum.photos/seed/dj36_{}/320/320"
        self.ua = ("Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 "
                   "(KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36")
        self.headers = {
            "User-Agent": self.ua,
            "Referer": self.host + "/",
            "Accept": "text/html,application/xhtml+xml,*/*;q=0.8",
        }
        try:
            self.ctx = ssl.create_default_context()
            self.ctx.check_hostname = False
            self.ctx.verify_mode = ssl.CERT_NONE
        except Exception:
            self.ctx = None
        self.cj = http.cookiejar.CookieJar()
        self.opener = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self.cj),
            urllib.request.HTTPSHandler(context=self.ctx),
        )
        self._cache = None
        self._classes = None

    def getName(self): return "36DJ舞曲"
    def isVideoFormat(self, url): return True
    def manualVideoCheck(self): return False
    def destroy(self): pass

    def _log(self, msg):
        try:
            d = "/sdcard/TVBox"
            if not os.path.exists(d):
                os.makedirs(d, exist_ok=True)
            with open(os.path.join(d, "dj36.log"), "a", encoding="utf-8") as f:
                f.write(str(msg) + "\n")
        except Exception:
            pass

    def _fetch(self, url, data=None, referer=None):
        try:
            body = urllib.parse.urlencode(data).encode("utf-8") if data else None
            hdr = dict(self.headers)
            if referer:
                hdr["Referer"] = referer
            if data:
                hdr["Content-Type"] = "application/x-www-form-urlencoded"
            req = urllib.request.Request(url, data=body, headers=hdr)
            resp = self.opener.open(req, timeout=15)
            raw = resp.read()
            for enc in ("utf-8", "gb18030", "gbk"):
                try:
                    return raw.decode(enc)
                except Exception:
                    continue
            return raw.decode("utf-8", "ignore")
        except Exception as e:
            self._log("fetch fail " + url[:120] + " " + repr(e)[:100])
            return ""

    def _get(self, url):
        return self._fetch(url)

    @staticmethod
    def _clean(raw):
        return re.sub(r"<[^>]+>", "", raw or "").strip()

    def _safe_pic(self, sid):
        return self.cover_tpl.format(sid)

    # ---------- 播放地址提取（核心）----------
    def _get_playurl(self, sid):
        """从详情页内联 JS 提取 playurl，拼接 CDN 完整直链"""
        html = self._get("{}/play/{}.html".format(self.host, sid))
        if not html:
            self._log("playurl NO html id=" + str(sid))
            return ""
        # var info = { "playurl": "2026/3609/04X/17540.m4a" };
        m = re.search(r'var\s+info\s*=\s*\{\s*"playurl"\s*:\s*"([^"]+)"', html)
        if not m:
            self._log("playurl NOT FOUND id=" + str(sid))
            return ""
        rel = m.group(1).strip()
        if rel.startswith("http"):
            return rel
        return self.cdn + "/" + rel.lstrip("/")

    # ---------- 列表解析 ----------
    def _parse_list(self, html):
        items, seen = [], set()
        try:
            # <a href="/play/17547.html" title="..." target="play">...</a>
            for m in re.finditer(
                r'<a\s+href="/play/(\d+)\.html"\s+title="([^"]*)"[^>]*>',
                html
            ):
                sid, title = m.group(1), m.group(2).strip()
                if sid in seen or not title:
                    continue
                seen.add(sid)
                items.append({
                    "vod_id": sid,
                    "vod_name": title,
                    "vod_pic": self._safe_pic(sid),
                    "vod_remarks": "",
                })
        except Exception as e:
            self._log("parse_list err: " + repr(e)[:120])
        return items

    # ---------- 详情 ----------
    def _detail(self, sid):
        try:
            html = self._get("{}/play/{}.html".format(self.host, sid))
            if not html:
                return {"list": []}

            m_title = re.search(r'<title>(.*?)_36DJ舞曲', html) \
                      or re.search(r'<title>(.*?)-', html)
            title = self._clean(m_title.group(1)) if m_title else ("DJ舞曲" + str(sid))

            play_url = self._get_playurl(sid)

            vod = {
                "vod_id": sid,
                "vod_name": title,
                "vod_pic": self._safe_pic(sid),
                "vod_actor": "",
                "vod_remarks": "",
                "vod_content": title,
            }
            if play_url:
                vod["vod_play_from"] = "36dj"
                vod["vod_play_url"] = "全集$" + play_url
                self._log("detail audio=" + play_url[:180])
            else:
                self._log("detail NO audio id=" + str(sid))

            return {"list": [vod]}
        except Exception as e:
            self._log("detail err " + repr(e)[:120])
            return {"list": []}

    # ---------- 分类 ----------
    def _load_classes(self):
        if self._classes is not None:
            return self._classes
        classes = [
            {"type_id": "xc",   "type_name": "串烧舞曲"},
            {"type_id": "myxc", "type_name": "慢摇串烧"},
            {"type_id": "zw",   "type_name": "中文舞曲"},
            {"type_id": "my",   "type_name": "慢摇舞曲"},
            {"type_id": "yw",   "type_name": "英文舞曲"},
            {"type_id": "top",  "type_name": "DJ舞曲榜"},
        ]
        self._classes = classes
        return classes

    def _home_list(self):
        if self._cache is not None:
            return self._cache
        html = self._get(self.host + "/")
        items = self._parse_list(html)
        self._cache = items[:30]
        return self._cache

    def homeContent(self, filter):
        return {"class": self._load_classes(), "list": self._home_list()}

    def homeVideoContent(self):
        return {"list": self._home_list()}

    # ---------- 分类内容（支持真分页）----------
    def categoryContent(self, tid, pg, filter, extend):
        tid = str(tid)
        try:
            pg_i = max(int(pg), 1)
        except Exception:
            pg_i = 1
        if pg_i == 1:
            path = "/{}/".format(tid)
        else:
            path = "/{}/index_{}.html".format(tid, pg_i)
        html = self._get(self.host + path)
        items = self._parse_list(html)

        # 从分页区提取总页数
        pagecount = 1
        m_pages = re.findall(r'<a\s+href="/[^/]+/index_(\d+)\.html"', html)
        if m_pages:
            pagecount = max(int(x) for x in m_pages)

        return {
            "list": items,
            "page": pg_i,
            "pagecount": pagecount,
            "limit": 30,
            "total": pagecount * 30,
        }

    def detailContent(self, ids):
        try:
            vid = ids[0] if isinstance(ids, list) else str(ids or "")
            if not vid:
                return {"list": []}
            sid = vid[1:] if vid[:1] in ("d", "v", "p") else vid
            return self._detail(sid)
        except Exception as e:
            self._log("detailContent err " + repr(e)[:120])
            return {"list": []}

    # ---------- 搜索（POST /e/search/index.php）----------
    def searchContent(self, key, quick):
        try:
            if not key:
                return {"list": []}
            html = self._fetch(
                self.host + "/e/search/index.php",
                data={
                    "classid": "1",
                    "keyboard": key,
                    "show": "title",
                    "tempid": "1",
                    "submit": "",
                },
                referer=self.host + "/"
            )
            items = self._parse_list(html)
            if not items:
                self._log("search empty key=" + str(key)[:50])
            return {"list": items}
        except Exception as e:
            self._log("search err " + repr(e)[:50])
            return {"list": []}

    # ---------- 播放 ----------
    def playerContent(self, flag, id, vipFlags):
        try:
            if not id:
                return {"parse": 0, "url": "", "playUrl": "", "header": ""}

            raw = str(id)
            if raw.startswith("http://") or raw.startswith("https://"):
                url = raw
            else:
                seg = raw.split("#")[0].split("$")[-1]
                if seg.isdigit():
                    url = self._get_playurl(seg)
                elif seg.startswith("http"):
                    url = seg
                else:
                    m = re.search(r"(\d+)", seg)
                    url = self._get_playurl(m.group(1)) if m else ""

            # .m4a 后缀可能被 TVBox 当网页嗅探，追加 ?ST=.mp4 伪装为视频直链
            if url and "?" not in url and not re.search(
                r"\.(mp4|mkv|m3u8|flv|avi|ts|rmvb|mov|wmv)$", url, re.I
            ):
                url = url + "?ST=.mp4"

            self._log("FINAL play url=" + url[:220])
            headers_text = "User-Agent: %s\r\nReferer: %s/\r\n" % (self.ua, self.host)

            return {
                "parse": 0,
                "url": url,
                "playUrl": url,
                "header": headers_text,
            }
        except Exception as e:
            self._log("player err " + repr(e)[:120])
            return {"parse": 0, "url": "", "playUrl": "", "header": ""}