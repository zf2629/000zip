#!/usr/bin/env python
# 看剧AI kanju3.ai
import re
import json
import time
import random
import hashlib
import hmac
from urllib.parse import quote

import requests

from base.spider import Spider


class Spider(Spider):

    def init(self, extend=""):
        self.host = "https://kanju3.ai"
        self.api = "https://kanju3.ai"
        self.key = b"557d0e4ae929f438da6bd84412374e6086b8af09b3fed54bf22601d5bf8c54a0"
        self.bh = "dianyingtiantang-v2026.09.08.3-6a4fbcaaef9f-web"
        self.pv = "2026-07-05.library-v2.playback-v1"
        self.ua = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
        self.s = requests.Session()
        self.s.headers.update({"User-Agent": self.ua, "Referer": "https://kanju3.ai/", "Origin": "https://kanju3.ai", "Accept": "application/json"})

    def getName(self):
        return "看剧AI"

    def isVideoFormat(self, url):
        return any(x in url for x in [".m3u8", ".mp4", "/m3u8", "resolve://"])

    def destroy(self):
        pass

    def _nonce(self):
        return "".join(random.choice("0123456789abcdef") for _ in range(32))

    def _sig(self, method, path, ts, nonce):
        msg = (method + "\n" + path + "\n" + ts + "\n" + nonce).encode("utf-8")
        return hmac.new(self.key, msg, hashlib.sha256).hexdigest()

    def _req(self, path, method="GET", body=None, retry=2):
        b = "" if body is None else json.dumps(body, separators=(",", ":"), ensure_ascii=False)
        for i in range(retry + 1):
            ts = str(int(time.time() * 1000))
            nonce = self._nonce()
            h = {
                "x-ai-movie-client-name": "dianyingtiantang-frontend",
                "x-ai-movie-client-version": "1.0.0",
                "x-ai-movie-build-version": self.bh,
                "x-ai-movie-protocol-version": self.pv,
                "x-ai-movie-timestamp": ts,
                "x-ai-movie-nonce": nonce,
                "x-ai-movie-signature": self._sig(method, path, ts, nonce),
            }
            if body is not None:
                h["Content-Type"] = "application/json"
            try:
                r = self.s.request(method, self.api + path, data=None if body is None else b.encode("utf-8"), headers=h, timeout=15)
                if r.status_code in (429, 500, 502, 503) and i < retry:
                    time.sleep(0.6 + i)
                    continue
                if r.status_code >= 400:
                    return None
                return r.json()
            except Exception:
                if i < retry:
                    time.sleep(0.5)
                    continue
                return None
        return None

    def _card(self, c):
        return {
            "vod_id": c.get("id") or c.get("selected_variant_id") or "",
            "vod_name": (c.get("title") or "").strip(),
            "vod_pic": c.get("poster_url") or "",
            "vod_remarks": c.get("remarks") or (str(c.get("year")) if c.get("year") else ""),
            "vod_year": str(c.get("year") or ""),
            "vod_area": c.get("area") or "",
            "type_name": c.get("content_kind") or "",
        }

    def homeContent(self, filter):
        cates = [
            {"type_name": "电影", "type_id": "movie"},
            {"type_name": "剧集", "type_id": "series"},
            {"type_name": "动漫", "type_id": "anime"},
            {"type_name": "综艺", "type_id": "variety"},
            {"type_name": "纪录片", "type_id": "documentary"},
            {"type_name": "短剧", "type_id": "short_drama"},
            {"type_name": "体育", "type_id": "sports"},
        ]
        fl = {}
        for c in cates:
            fl[c["type_id"]] = [
                {"key": "sort", "name": "排序", "value": [{"n": "最新", "v": "latest"}, {"n": "热门", "v": "trending"}]},
            ]
        return {"class": cates, "filters": fl}

    def homeVideoContent(self):
        j = self._req("/v1/feed/home?scope=public&mode=preview&sections=3&cards=12")
        out = []
        if j and isinstance(j.get("sections"), list):
            seen = set()
            for sec in j["sections"]:
                for c in sec.get("cards") or []:
                    v = self._card(c)
                    if v["vod_id"] and v["vod_id"] not in seen:
                        seen.add(v["vod_id"])
                        out.append(v)
        return {"list": out}

    def categoryContent(self, tid, pg, filter, extend):
        try:
            pg = int(pg)
        except Exception:
            pg = 1
        ext = extend or {}
        if isinstance(ext, str):
            try:
                ext = json.loads(ext)
            except Exception:
                ext = {}
        params = {"page": str(pg), "limit": "24"}
        if tid and tid != "all":
            params["kind"] = tid
        sort = ext.get("sort") or "latest"
        if sort == "trending":
            params["sort"] = "trending"
        qs = "&".join(k + "=" + quote(str(v), safe="") for k, v in params.items())
        j = self._req("/v1/browse/catalog?" + qs)
        cards = (j or {}).get("cards") or []
        out = []
        seen = set()
        for c in cards:
            v = self._card(c)
            if v["vod_id"] and v["vod_id"] not in seen:
                seen.add(v["vod_id"])
                out.append(v)
        has_more = len(cards) >= 24
        return {"list": out, "page": pg, "pagecount": 9999 if has_more else pg, "limit": 24, "total": 999999 if has_more else len(out)}

    def detailContent(self, ids):
        vid = ids[0] if isinstance(ids, list) else ids
        j = self._req("/v1/catalog/" + quote(vid, safe=""))
        if not j or j.get("object") != "catalog.detail":
            return {"list": []}
        v = self._card(j)
        v["vod_content"] = j.get("description") or j.get("remarks") or ""
        v["vod_actor"] = " , ".join(j.get("actors") or [])
        v["vod_director"] = " , ".join(j.get("directors") or [])
        genres = j.get("genres") or []
        if genres:
            v["type_name"] = genres[0]
        eps = []
        pag = j.get("episode_pagination") or {}
        ep_list = j.get("episodes") or []
        if ep_list:
            eps.extend(ep_list)
        if pag.get("has_more"):
            limit = pag.get("limit") or 50
            total = pag.get("total_count") or pag.get("returned_count") or pag.get("available_episode_count") or 0
            try:
                total = int(total)
            except Exception:
                total = 0
            offset = len(eps)
            while offset < total:
                pj = self._req("/v1/catalog/" + quote(vid, safe="") + "/episodes?offset=" + str(offset) + "&limit=" + str(limit) + "&order=start")
                if not pj or not pj.get("episodes"):
                    break
                chunk = pj.get("episodes") or []
                eps.extend(chunk)
                if not ((pj.get("episode_pagination") or {}).get("has_more")):
                    break
                offset += len(chunk)
        groups = {}
        order = []
        for e in eps:
            line = e.get("episode_track") or "main"
            tok = e.get("token") or ""
            if not tok:
                continue
            name = (e.get("title") or e.get("display_name") or ("第" + str(e.get("number")) + "集" if e.get("number") else "播放")).strip()
            groups.setdefault(line, []).append(name + "$" + tok)
        if not groups:
            return {"list": [v]}
        toks = groups.get("main") or next(iter(groups.values()))
        play_from = []
        play_url = []
        labels = self._line_labels(toks[0].split("$")[-1])
        if labels:
            for lb in labels:
                play_from.append(lb)
                play_url.append("#".join(toks))
        else:
            labelmap = {"main": "默认线路", "trailer": "预告"}
            for line in order:
                play_from.append(labelmap.get(line, line))
                play_url.append("#".join(groups[line]))
        v["vod_play_from"] = "$$$".join(play_from)
        v["vod_play_url"] = "$$$".join(play_url)
        return {"list": [v]}

    def _line_labels(self, tok):
        try:
            j = self._req("/v1/playback/resolve/" + quote(tok, safe=""))
            los = (j or {}).get("line_options") or []
            los.sort(key=lambda x: (0 if x.get("selected") else 1, -(x.get("preference_weight") or 0)))
            return [lo.get("display_label") or lo.get("label") or lo.get("id") for lo in los if lo.get("display_label") or lo.get("label")]
        except Exception:
            return []

    def searchContent(self, key, quick, pg="1"):
        try:
            pg = int(pg)
        except Exception:
            pg = 1
        qs = "q=" + quote(key or "", safe="") + "&page=" + str(pg) + "&limit=20"
        j = self._req("/v1/browse/catalog?" + qs)
        cards = (j or {}).get("cards") or []
        out = []
        seen = set()
        for c in cards:
            v = self._card(c)
            if v["vod_id"] and v["vod_id"] not in seen:
                seen.add(v["vod_id"])
                out.append(v)
        has_more = len(cards) >= 20
        return {"list": out, "page": pg, "pagecount": 9999 if has_more else pg, "limit": 20, "total": 999999 if has_more else len(out)}

    def searchContentPage(self, key, quick, pg):
        return self.searchContent(key, quick, pg)

    def _resolve_line(self, tok, lo):
        if lo.get("resolved") and lo.get("url_kind") in ("m3u8", "mp4"):
            u = lo.get("url") or ""
            if u.startswith("http"):
                return u
        ticket = lo.get("url") or ""
        if not ticket:
            return ""
        j = self._req("/v1/playback/resolve-line", "POST", {"playback_source_id": lo.get("playback_source_id") or lo.get("id"), "ticket": ticket})
        if j and isinstance(j.get("line"), dict):
            u = (j["line"].get("url") or "")
            if u.startswith("http"):
                return u
        return ""

    def playerContent(self, flag, id, vipFlags):
        h = {"User-Agent": self.ua, "Referer": "https://kanju3.ai/"}
        empty = {"parse": 0, "playUrl": "", "url": "", "header": json.dumps(h)}
        j = self._req("/v1/playback/resolve/" + quote(id, safe=""))
        if not j or j.get("object") != "playback.resolve":
            return empty
        los = j.get("line_options") or []
        target = (flag or "").strip()
        if target:
            for lo in los:
                if (lo.get("display_label") or lo.get("label") or "").strip() == target:
                    u = self._resolve_line(id, lo)
                    if u:
                        return {"parse": 0, "playUrl": "", "url": u, "header": json.dumps(h)}
        los.sort(key=lambda x: (0 if x.get("selected") else 1, -(x.get("preference_weight") or 0)))
        for lo in los:
            u = self._resolve_line(id, lo)
            if u:
                return {"parse": 0, "playUrl": "", "url": u, "header": json.dumps(h)}
        return empty

    def localProxy(self, param):
        return [200, "text/plain", "", ""]